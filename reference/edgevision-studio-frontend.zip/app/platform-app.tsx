"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Button,
  Checkbox,
  Content,
  Dropdown,
  Header,
  HeaderGlobalAction,
  HeaderGlobalBar,
  HeaderMenuButton,
  HeaderName,
  InlineLoading,
  InlineNotification,
  Modal,
  ProgressBar,
  Search,
  Select,
  SelectItem,
  SideNav,
  SideNavItems,
  SideNavLink,
  SkeletonText,
  Tag,
  TextInput,
  Theme,
  Tile,
  Toggle,
} from "@carbon/react";
import {
  Activity,
  Add,
  Asleep,
  CheckmarkFilled,
  Code,
  Compare,
  Dashboard,
  DataBase,
  DataView,
  Deploy,
  Document,
  Download,
  EdgeNode,
  Folder,
  Help,
  MachineLearningModel,
  Model,
  Notification,
  Play,
  Renew,
  Screen,
  Search as SearchIcon,
  Settings,
  Sun,
  Task,
  Upload,
  UserAvatar,
  UserMultiple,
  WarningAltFilled,
} from "@carbon/icons-react";
import { DonutChart, LineChart, SimpleBarChart } from "@carbon/charts-react";
import { ScaleTypes, type DonutChartOptions, type LineChartOptions, type SimpleBarChartOptions } from "@carbon/charts";

type Role = "client" | "admin";
type ThemeName = "g10" | "g100";

type Metric = { label: string; value: string; detail: string };
type RunningTask = {
  name: string;
  project: string;
  stage: string;
  progress: number;
  resource: string;
  time: string;
};
type ProjectRow = {
  name: string;
  dataset: string;
  models: number;
  updated: string;
  status: string;
};
type OverviewData = { metrics: Metric[]; tasks: RunningTask[]; projects: ProjectRow[] };

const clientNav = [
  { id: "overview", label: "工作台", icon: Dashboard },
  { id: "projects", label: "我的项目", icon: Folder },
  { id: "datasets", label: "数据集管理", icon: DataBase },
  { id: "models", label: "模型管理", icon: Model },
  { id: "training", label: "训练任务", icon: Task },
  { id: "compare", label: "实验对比", icon: Compare },
  { id: "convert", label: "模型转换", icon: MachineLearningModel },
  { id: "testing", label: "在线测试", icon: Screen },
  { id: "devices", label: "边缘部署", icon: EdgeNode },
  { id: "code", label: "代码生成", icon: Code },
  { id: "help", label: "帮助与文档", icon: Help },
];

const adminNav = [
  { id: "overview", label: "管理仪表盘", icon: Dashboard },
  { id: "users", label: "用户管理", icon: UserMultiple },
  { id: "projects", label: "全平台项目", icon: Folder },
  { id: "datasets", label: "数据集与模型", icon: DataView },
  { id: "training", label: "训练与实验", icon: Task },
  { id: "convert", label: "转换与测试", icon: MachineLearningModel },
  { id: "devices", label: "边缘设备", icon: EdgeNode },
  { id: "resources", label: "系统资源", icon: Activity },
  { id: "settings", label: "系统设置", icon: Settings },
  { id: "logs", label: "日志中心", icon: Document },
];

const lossData = Array.from({ length: 12 }, (_, index) => [
  { group: "Box Loss", epoch: index * 5 + 5, value: Number((1.84 * Math.exp(-index / 5) + 0.16).toFixed(3)) },
  { group: "Cls Loss", epoch: index * 5 + 5, value: Number((1.36 * Math.exp(-index / 4.4) + 0.11).toFixed(3)) },
]).flat();

const metricData = Array.from({ length: 12 }, (_, index) => [
  { group: "Precision", epoch: index * 5 + 5, value: Number((0.52 + index * 0.034).toFixed(3)) },
  { group: "mAP@0.5", epoch: index * 5 + 5, value: Number((0.46 + index * 0.038).toFixed(3)) },
]).flat();

const lineOptions: LineChartOptions = {
  height: "260px",
  toolbar: { enabled: false },
  legend: { alignment: "center" },
  axes: {
    bottom: { title: "Epoch", mapsTo: "epoch", scaleType: ScaleTypes.LINEAR },
    left: { mapsTo: "value", scaleType: ScaleTypes.LINEAR },
  },
  curve: "curveMonotoneX",
  points: { enabled: false },
};

const taskTrendData = [
  { group: "训练任务", day: "周一", value: 18 },
  { group: "训练任务", day: "周二", value: 25 },
  { group: "训练任务", day: "周三", value: 21 },
  { group: "训练任务", day: "周四", value: 32 },
  { group: "训练任务", day: "周五", value: 29 },
  { group: "训练任务", day: "周六", value: 16 },
  { group: "训练任务", day: "周日", value: 23 },
];

const barOptions: SimpleBarChartOptions = {
  height: "250px",
  toolbar: { enabled: false },
  legend: { enabled: false },
  axes: {
    bottom: { mapsTo: "day", scaleType: ScaleTypes.LABELS },
    left: { mapsTo: "value", scaleType: ScaleTypes.LINEAR },
  },
};

const formatData = [
  { group: "PyTorch", value: 48 },
  { group: "ONNX", value: 31 },
  { group: "RKNN", value: 21 },
];

const donutOptions: DonutChartOptions = {
  height: "250px",
  toolbar: { enabled: false },
  donut: { center: { label: "模型格式" }, alignment: "center" },
  legend: { alignment: "center" },
};

function statusTag(status: string) {
  if (["训练中", "验证中", "进行中", "正常", "模型量化中"].includes(status)) return <Tag type="green">{status}</Tag>;
  if (["等待中", "数据检查"].includes(status)) return <Tag type="warm-gray">{status}</Tag>;
  return <Tag type="red">{status}</Tag>;
}

export function PlatformApp() {
  const [role, setRole] = useState<Role>("client");
  const [view, setView] = useState("overview");
  const [theme, setTheme] = useState<ThemeName>("g10");
  const [sideOpen, setSideOpen] = useState(false);
  const [overview, setOverview] = useState<OverviewData | null>(null);
  const [loadError, setLoadError] = useState(false);

  const nav = role === "client" ? clientNav : adminNav;
  const activeLabel = nav.find((item) => item.id === view)?.label ?? "工作台";

  useEffect(() => {
    let active = true;
    fetch(`/api/overview?role=${role}`)
      .then((response) => {
        if (!response.ok) throw new Error("overview request failed");
        return response.json() as Promise<OverviewData>;
      })
      .then((data) => active && setOverview(data))
      .catch(() => active && setLoadError(true));
    return () => {
      active = false;
    };
  }, [role]);

  const switchRole = (nextRole: Role) => {
    setOverview(null);
    setLoadError(false);
    setRole(nextRole);
    setView("overview");
    setSideOpen(false);
  };

  return (
    <Theme theme={theme} className="platform-theme">
      <Header aria-label="EdgeVision Studio">
        <HeaderMenuButton
          aria-label={sideOpen ? "关闭导航" : "打开导航"}
          isActive={sideOpen}
          onClick={() => setSideOpen((value) => !value)}
        />
        <HeaderName href="#" prefix="">
          <span className="product-mark" aria-hidden="true" />
          EdgeVision Studio
        </HeaderName>
        <div className="header-context">
          <span>{role === "client" ? "客户端" : "管理端"}</span>
          <span className="connection-state"><i /> 实时服务已连接</span>
        </div>
        <HeaderGlobalBar>
          <HeaderGlobalAction aria-label="搜索"><SearchIcon size={20} /></HeaderGlobalAction>
          <HeaderGlobalAction aria-label="通知"><Notification size={20} /></HeaderGlobalAction>
          <HeaderGlobalAction aria-label="切换主题" onClick={() => setTheme((value) => value === "g10" ? "g100" : "g10")}>
            {theme === "g10" ? <Asleep size={20} /> : <Sun size={20} />}
          </HeaderGlobalAction>
          <HeaderGlobalAction aria-label="个人中心"><UserAvatar size={20} /></HeaderGlobalAction>
        </HeaderGlobalBar>
      </Header>

      <SideNav aria-label="功能导航" expanded={sideOpen} isFixedNav isChildOfHeader={false}>
        <div className="role-switch" aria-label="切换使用端">
          <button className={role === "client" ? "is-active" : ""} onClick={() => switchRole("client")}>客户端</button>
          <button className={role === "admin" ? "is-active" : ""} onClick={() => switchRole("admin")}>管理端</button>
        </div>
        <SideNavItems>
          {nav.map((item) => (
            <SideNavLink
              key={item.id}
              href={`#${item.id}`}
              renderIcon={item.icon}
              isActive={view === item.id}
              onClick={(event) => {
                event.preventDefault();
                setView(item.id);
                setSideOpen(false);
              }}
            >
              {item.label}
            </SideNavLink>
          ))}
        </SideNavItems>
        <div className="side-account">
          <span className="avatar">胡</span>
          <div><strong>胡力文</strong><small>{role === "client" ? "普通用户" : "系统管理员"}</small></div>
        </div>
      </SideNav>

      <Content className="app-content">
        <div className="content-head">
          <div>
            <h1>{activeLabel}</h1>
            <p>{role === "client" ? "管理项目、训练任务、模型转换与边缘部署。" : "监控平台运行状态并管理全局资源与权限。"}</p>
          </div>
          <GlobalTask />
        </div>

        {view === "overview" ? (
          <Overview role={role} data={overview} error={loadError} />
        ) : view === "training" ? (
          <TrainingMonitor role={role} />
        ) : view === "convert" ? (
          <ConversionView role={role} />
        ) : view === "resources" ? (
          <ResourceView />
        ) : (
          <ManagementView role={role} view={view} title={activeLabel} />
        )}
      </Content>
    </Theme>
  );
}

function GlobalTask() {
  return (
    <button className="global-task" type="button">
      <InlineLoading status="active" description="2 个后台任务运行中" />
    </button>
  );
}

function Overview({ role, data, error }: { role: Role; data: OverviewData | null; error: boolean }) {
  if (error) {
    return <InlineNotification kind="error" title="无法加载仪表盘" subtitle="请检查网络连接或稍后重试。" actionButtonLabel="重试" />;
  }
  if (!data) return <OverviewSkeleton />;

  return (
    <div className="view-stack">
      <section className="metric-band" aria-label="核心指标">
        {data.metrics.map((metric) => (
          <article key={metric.label}>
            <span>{metric.label}</span>
            <strong>{metric.value}</strong>
            <small>{metric.detail}</small>
          </article>
        ))}
      </section>

      {role === "client" ? <ClientOverview data={data} /> : <AdminOverview data={data} />}
    </div>
  );
}

function OverviewSkeleton() {
  return (
    <div className="view-stack">
      <section className="metric-band skeleton-band">
        {[0, 1, 2, 3].map((item) => <article key={item}><SkeletonText heading /><SkeletonText /></article>)}
      </section>
      <Tile className="loading-tile"><SkeletonText heading /><SkeletonText paragraph lineCount={8} /></Tile>
    </div>
  );
}

function ClientOverview({ data }: { data: OverviewData }) {
  return (
    <>
      <section className="split-zone">
        <div className="panel running-panel">
          <div className="panel-head"><div><h2>运行中的训练</h2><p>任务状态通过 WebSocket 更新</p></div><Button kind="ghost" size="sm" renderIcon={Task}>全部任务</Button></div>
          <TaskTable tasks={data.tasks} />
        </div>
        <div className="quick-zone">
          <h2>快捷操作</h2>
          <div className="quick-grid">
            <Button kind="primary" renderIcon={Add}>新建项目</Button>
            <Button kind="secondary" renderIcon={Upload}>上传数据集</Button>
            <Button kind="tertiary" renderIcon={Play}>创建训练</Button>
            <Button kind="ghost" renderIcon={Deploy}>转换模型</Button>
          </div>
          <InlineNotification lowContrast hideCloseButton kind="info" title="设备提示" subtitle="RK3588-实验台-03 已恢复在线，可提交部署任务。" />
        </div>
      </section>
      <section className="panel">
        <div className="panel-head"><div><h2>最近项目</h2><p>按最近活动时间排序</p></div><Button kind="ghost" size="sm" renderIcon={Folder}>项目管理</Button></div>
        <ProjectTable rows={data.projects} role="client" />
      </section>
    </>
  );
}

function AdminOverview({ data }: { data: OverviewData }) {
  return (
    <>
      <section className="chart-grid">
        <div className="panel chart-panel"><div className="panel-head"><div><h2>最近 7 天任务趋势</h2><p>训练任务提交数量</p></div></div><SimpleBarChart data={taskTrendData} options={barOptions} /></div>
        <div className="panel chart-panel"><div className="panel-head"><div><h2>模型格式分布</h2><p>全平台可用模型</p></div></div><DonutChart data={formatData} options={donutOptions} /></div>
      </section>
      <section className="split-zone admin-split">
        <div className="panel"><div className="panel-head"><div><h2>平台运行任务</h2><p>按资源占用优先展示</p></div><Button kind="ghost" size="sm" renderIcon={Renew}>重新调度</Button></div><TaskTable tasks={data.tasks} /></div>
        <div className="panel alert-panel"><div className="panel-head"><div><h2>系统告警</h2><p>最近 24 小时</p></div></div>
          <div className="alert-list">
            <Alert icon={WarningAltFilled} title="GPU 3 温度较高" detail="82°C，已降低新任务调度权重" kind="warning" />
            <Alert icon={CheckmarkFilled} title="Redis 连接恢复" detail="连接池状态正常" kind="success" />
            <Alert icon={WarningAltFilled} title="对象存储接近阈值" detail="使用率 68%，建议清理过期训练结果" kind="warning" />
          </div>
        </div>
      </section>
      <section className="panel"><div className="panel-head"><div><h2>基础设施摘要</h2><p>由系统监控接口实时汇总</p></div></div><ProjectTable rows={data.projects} role="admin" /></section>
    </>
  );
}

function Alert({ icon: Icon, title, detail, kind }: { icon: typeof WarningAltFilled; title: string; detail: string; kind: "warning" | "success" }) {
  return <article className={`alert-item ${kind}`}><Icon size={20} /><div><strong>{title}</strong><p>{detail}</p></div></article>;
}

function TaskTable({ tasks }: { tasks: RunningTask[] }) {
  return (
    <div className="table-scroll">
      <table className="data-table">
        <thead><tr><th>任务</th><th>状态</th><th>进度</th><th>运行资源</th><th>已运行</th></tr></thead>
        <tbody>{tasks.map((task) => (
          <tr key={task.name}>
            <td><strong>{task.name}</strong><small>{task.project}</small></td>
            <td>{statusTag(task.stage)}</td>
            <td><ProgressBar size="small" label="" hideLabel value={task.progress} /><small>{task.progress}%</small></td>
            <td>{task.resource}</td><td>{task.time}</td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  );
}

function ProjectTable({ rows, role }: { rows: ProjectRow[]; role: Role }) {
  return (
    <div className="table-scroll"><table className="data-table"><thead><tr><th>{role === "client" ? "项目名称" : "监控项"}</th><th>{role === "client" ? "关联数据集" : "当前状态"}</th><th>{role === "client" ? "模型数" : "数值"}</th><th>更新时间</th><th>状态</th></tr></thead>
      <tbody>{rows.map((row) => <tr key={row.name}><td><strong>{row.name}</strong></td><td>{row.dataset}</td><td>{row.models}</td><td>{row.updated}</td><td>{statusTag(row.status)}</td></tr>)}</tbody>
    </table></div>
  );
}

function TrainingMonitor({ role }: { role: Role }) {
  const [epoch, setEpoch] = useState(42);
  const [autoScroll, setAutoScroll] = useState(true);
  const [logFilter, setLogFilter] = useState("");
  const logs = useMemo(() => [
    `[10:42:11] Epoch ${epoch}/100  GPU_mem 18.4G  box_loss 0.482  cls_loss 0.327`,
    "[10:42:12] 684/684 batches complete, 127.3 it/s",
    "[10:42:18] validating aluminum-v4 split=val images=2480",
    "[10:42:29] Precision 0.871  Recall 0.842  mAP50 0.895  mAP50-95 0.648",
    "[10:42:31] checkpoint saved: runs/aluminum-yolo11s/weights/last.pt",
  ].filter((line) => line.toLowerCase().includes(logFilter.toLowerCase())), [epoch, logFilter]);

  useEffect(() => {
    const timer = window.setInterval(() => setEpoch((value) => value >= 99 ? 42 : value + 1), 5000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="view-stack">
      <InlineNotification lowContrast hideCloseButton kind="info" title={role === "admin" ? "管理员监控模式" : "训练实时连接正常"} subtitle="指标与日志正在通过 WebSocket 持续更新。" />
      <section className="monitor-summary">
        <div><span>任务状态</span><strong><Tag type="green">训练中</Tag></strong></div>
        <div><span>当前 Epoch</span><strong>{epoch} / 100</strong></div>
        <div><span>预计剩余</span><strong>01:18:26</strong></div>
        <div><span>GPU / 显存</span><strong>78% / 18.4 GB</strong></div>
        <div><span>GPU 温度</span><strong>67°C</strong></div>
      </section>
      <div className="panel progress-panel"><div className="progress-copy"><strong>铝件表面缺陷-yolo11s</strong><span>Epoch {epoch} 正在训练</span></div><ProgressBar label="训练总进度" hideLabel value={epoch} /></div>
      <section className="chart-grid"><div className="panel chart-panel"><div className="panel-head"><div><h2>Loss 变化</h2><p>Box Loss 与 Classification Loss</p></div></div><LineChart data={lossData} options={lineOptions} /></div>
        <div className="panel chart-panel"><div className="panel-head"><div><h2>验证指标</h2><p>Precision 与 mAP@0.5</p></div></div><LineChart data={metricData} options={lineOptions} /></div></section>
      <section className="panel log-panel">
        <div className="panel-head log-head"><div><h2>实时训练日志</h2><p>前端清空不会删除后端日志</p></div><div className="log-actions"><Search size="sm" placeholder="搜索日志" labelText="搜索日志" value={logFilter} onChange={(event) => setLogFilter(event.target.value)} /><Toggle id="auto-scroll" size="sm" labelText="自动滚动" toggled={autoScroll} onToggle={setAutoScroll} /><Button kind="ghost" size="sm" renderIcon={Download}>下载</Button></div></div>
        <pre aria-live="polite">{logs.join("\n")}</pre>
      </section>
    </div>
  );
}

function ConversionView({ role }: { role: Role }) {
  const models = ["aluminum-yolo11s-best.pt", "helmet-v7-best.pt", "pcb-solder-last.pt"];
  const [format, setFormat] = useState("RKNN");
  const [quantize, setQuantize] = useState(true);
  const [modal, setModal] = useState(false);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!running || progress >= 100) return;
    const timer = window.setTimeout(() => setProgress((value) => Math.min(100, value + 14)), 700);
    return () => window.clearTimeout(timer);
  }, [running, progress]);

  return (
    <div className="view-stack">
      {role === "admin" && <InlineNotification lowContrast hideCloseButton kind="warning" title="全平台操作" subtitle="管理员可查看并重新执行所有用户的转换任务。" />}
      <section className="wizard-grid">
        <div className="panel form-panel">
          <div className="panel-head"><div><h2>创建模型转换</h2><p>源模型、目标格式和运行参数</p></div></div>
          <div className="form-stack">
            <Dropdown id="source-model" titleText="源模型" label="选择源模型" items={models} initialSelectedItem={models[0]} />
            <Select id="target-format" labelText="目标格式" value={format} onChange={(event) => setFormat(event.target.value)}><SelectItem value="ONNX" text="ONNX" /><SelectItem value="RKNN" text="RKNN" /></Select>
            <div className="form-row"><TextInput id="input-width" labelText="输入宽度" defaultValue="640" /><TextInput id="input-height" labelText="输入高度" defaultValue="640" /></div>
            {format === "RKNN" ? <><Select id="target-chip" labelText="目标芯片" defaultValue="rk3588"><SelectItem value="rk3588" text="RK3588" /><SelectItem value="rk3568" text="RK3568" /></Select><Toggle id="int8" labelText="启用 INT8 量化" toggled={quantize} onToggle={setQuantize} /><Dropdown id="calibration" titleText="校准数据集" label="选择校准数据集" items={["aluminum-calib-256", "aluminum-val-500"]} initialSelectedItem="aluminum-calib-256" /></> : <><Select id="opset" labelText="Opset 版本" defaultValue="17"><SelectItem value="17" text="17" /><SelectItem value="18" text="18" /></Select><Checkbox id="simplify" labelText="简化 ONNX 图" defaultChecked /></>}
            <Button renderIcon={Play} onClick={() => setModal(true)}>检查并提交</Button>
          </div>
        </div>
        <div className="panel summary-panel">
          <div className="panel-head"><div><h2>转换摘要</h2><p>提交前由后端执行环境检查</p></div></div>
          <dl><div><dt>源模型</dt><dd>aluminum-yolo11s-best.pt</dd></div><div><dt>目标格式</dt><dd>{format}</dd></div><div><dt>输入尺寸</dt><dd>640 × 640</dd></div><div><dt>目标芯片</dt><dd>{format === "RKNN" ? "RK3588" : "通用运行时"}</dd></div><div><dt>精度模式</dt><dd>{format === "RKNN" && quantize ? "INT8" : "FP16"}</dd></div></dl>
          {running ? <div className="conversion-progress"><ProgressBar label={progress >= 100 ? "转换完成" : "模型转换中"} value={progress} />{progress >= 100 ? <Button kind="tertiary" renderIcon={Download}>下载模型</Button> : <InlineLoading description="正在构建并验证模型" />}</div> : <div className="empty-state"><MachineLearningModel size={40} /><h3>等待提交转换任务</h3><p>任务开始后，这里会显示步骤、进度和实时日志。</p></div>}
        </div>
      </section>
      <Modal open={modal} modalHeading="确认提交转换任务" primaryButtonText="提交任务" secondaryButtonText="返回修改" onRequestClose={() => setModal(false)} onRequestSubmit={() => { setModal(false); setRunning(true); setProgress(8); }}>
        <p>平台将使用 RK3588 配置和 aluminum-calib-256 校准集生成 INT8 RKNN 模型。</p>
      </Modal>
    </div>
  );
}

const managementRows: Record<string, Array<[string, string, string, string]>> = {
  projects: [["铝件表面缺陷", "胡力文", "进行中", "12 分钟前"], ["包装线破损检测", "罗洪斌", "已归档", "昨天"], ["PCB焊点质检", "邓鸿文", "数据检查", "2 小时前"]],
  datasets: [["aluminum-v4", "18,420 张图片", "检查通过", "8.6 GB"], ["helmet-site-v2", "9,842 张图片", "检查通过", "4.1 GB"], ["pcb-solder-v1", "6,120 张图片", "发现 12 个问题", "3.8 GB"]],
  models: [["aluminum-yolo11s-best", "PyTorch", "mAP50 0.895", "19.8 MB"], ["helmet-v7-rk3588", "RKNN", "INT8", "12.4 MB"], ["pcb-solder-onnx", "ONNX", "FP16", "28.6 MB"]],
  users: [["罗洪斌", "系统管理员", "已启用", "今天 09:41"], ["邓鸿文", "普通用户", "已启用", "昨天 18:22"], ["周启明", "普通用户", "已禁用", "7 天前"]],
  devices: [["RK3588-实验台-01", "RK3588", "在线", "21 ms"], ["RK3588-产线-A3", "RK3588", "在线", "18 ms"], ["RK3568-测试机", "RK3568", "离线", "无数据"]],
};

function ManagementView({ role, view, title }: { role: Role; view: string; title: string }) {
  const source = managementRows[view] ?? managementRows[view === "testing" ? "models" : view === "code" ? "models" : view === "compare" ? "projects" : role === "admin" ? "projects" : "datasets"];
  return (
    <div className="view-stack">
      <section className="management-toolbar"><Search placeholder={`搜索${title}`} labelText={`搜索${title}`} /><Dropdown id="status-filter" label="全部状态" items={["全部状态", "运行中", "已完成", "失败"]} initialSelectedItem="全部状态" /><Button renderIcon={view === "help" ? Help : Add}>{view === "help" ? "查看指南" : "新建"}</Button></section>
      <section className="panel">
        <div className="panel-head"><div><h2>{title}</h2><p>支持搜索、筛选、排序、分页和批量操作</p></div><div className="panel-actions"><Button kind="ghost" size="sm" renderIcon={Download}>导出</Button><Button kind="ghost" size="sm" renderIcon={Renew}>刷新</Button></div></div>
        <div className="table-scroll"><table className="data-table"><thead><tr><th>名称</th><th>类型 / 所属</th><th>状态 / 指标</th><th>更新 / 大小</th><th>操作</th></tr></thead><tbody>{source.map((row) => <tr key={row[0]}><td><strong>{row[0]}</strong></td><td>{row[1]}</td><td>{statusTag(row[2])}</td><td>{row[3]}</td><td><Button kind="ghost" size="sm">查看详情</Button></td></tr>)}</tbody></table></div>
        <div className="pagination-note">第 1-3 条，共 28 条</div>
      </section>
    </div>
  );
}

function ResourceView() {
  const resources = [{ name: "GPU 0 / RTX 4090", value: 78, detail: "18.4 / 24 GB · 67°C" }, { name: "GPU 1 / RTX 4090", value: 54, detail: "12.8 / 24 GB · 61°C" }, { name: "CPU / AMD EPYC", value: 42, detail: "54 / 128 核心" }, { name: "内存", value: 63, detail: "161 / 256 GB" }, { name: "磁盘", value: 68, detail: "6.82 / 10 TB" }];
  return <div className="view-stack"><section className="resource-grid">{resources.map((item) => <Tile key={item.name} className="resource-tile"><div><strong>{item.name}</strong><span>{item.detail}</span></div><ProgressBar label="" hideLabel value={item.value} /><b>{item.value}%</b></Tile>)}</section><section className="panel"><div className="panel-head"><div><h2>服务连接状态</h2><p>Celery、Redis、数据库和 WebSocket</p></div></div><div className="service-grid"><Service name="Celery Worker" detail="8 / 8 在线" /><Service name="Redis" detail="连接池正常" /><Service name="PostgreSQL" detail="12 个活动连接" /><Service name="WebSocket" detail="284 个连接" /></div></section></div>;
}

function Service({ name, detail }: { name: string; detail: string }) {
  return <article><i /><div><strong>{name}</strong><span>{detail}</span></div></article>;
}

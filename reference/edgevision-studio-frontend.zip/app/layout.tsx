import type { Metadata } from "next";
import "@carbon/styles/css/styles.css";
import "@carbon/charts-react/styles.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "EdgeVision Studio | YOLO 训练与边缘部署平台",
  description: "面向 YOLO 模型训练、ONNX/RKNN 转换与 RK3588 边缘部署的双端平台前端。",
  other: { "codex-preview": "development" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}

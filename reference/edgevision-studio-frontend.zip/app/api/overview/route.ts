import { NextResponse } from "next/server";

const clientData = {
  metrics: [
    { label: "我的项目", value: "12", detail: "本月新增 3 个" },
    { label: "正在训练", value: "3", detail: "2 个使用 GPU" },
    { label: "可用模型", value: "28", detail: "包含 6 个 RKNN" },
    { label: "边缘设备", value: "4 / 5", detail: "1 台设备离线" },
  ],
  tasks: [
    { name: "铝件表面缺陷-yolo11s", project: "铝件质检", stage: "训练中", progress: 68, resource: "RTX 4090 / 18.4 GB", time: "01:42:18" },
    { name: "安全帽检测-v7", project: "工地安全", stage: "验证中", progress: 92, resource: "RTX 3090 / 13.1 GB", time: "03:08:44" },
    { name: "PCB焊点-quick-test", project: "PCB质检", stage: "等待中", progress: 0, resource: "等待调度", time: "00:00:00" },
  ],
  projects: [
    { name: "铝件表面缺陷", dataset: "aluminum-v4", models: 8, updated: "12 分钟前", status: "进行中" },
    { name: "工地安全检测", dataset: "helmet-site-v2", models: 5, updated: "2 小时前", status: "进行中" },
    { name: "PCB焊点质检", dataset: "pcb-solder-v1", models: 3, updated: "昨天 18:20", status: "数据检查" },
  ],
};

const adminData = {
  metrics: [
    { label: "全平台项目", value: "126", detail: "今日新增 7 个" },
    { label: "运行中任务", value: "18", detail: "队列中 9 个" },
    { label: "在线设备", value: "31 / 35", detail: "可用率 88.6%" },
    { label: "今日失败", value: "4", detail: "较昨日减少 2 个" },
  ],
  tasks: [
    { name: "包装破损-yolo11m", project: "包装线质检", stage: "训练中", progress: 44, resource: "GPU 2 / 21.8 GB", time: "00:51:26" },
    { name: "铸件气孔-rknn", project: "铸件检测", stage: "模型量化中", progress: 76, resource: "Worker convert-03", time: "00:12:09" },
    { name: "口罩佩戴检测", project: "园区安防", stage: "训练中", progress: 61, resource: "GPU 0 / 16.2 GB", time: "02:21:13" },
  ],
  projects: [
    { name: "GPU 调度压力", dataset: "18 个运行任务", models: 72, updated: "实时", status: "正常" },
    { name: "对象存储", dataset: "6.82 TB / 10 TB", models: 68, updated: "1 分钟前", status: "正常" },
    { name: "WebSocket 连接", dataset: "284 个活跃连接", models: 284, updated: "实时", status: "正常" },
  ],
};

export async function GET(request: Request) {
  const role = new URL(request.url).searchParams.get("role");
  return NextResponse.json(role === "admin" ? adminData : clientData);
}
